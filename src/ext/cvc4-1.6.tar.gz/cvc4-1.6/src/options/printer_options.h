/*********************                                                        */
/*! \file module_template.h
 ** \verbatim
 ** Top contributors (to current version):
 **   Mathias Preiner
 ** This file is part of the CVC4 project.
 ** Copyright (c) 2009-2018 by the authors listed in the file AUTHORS
 ** in the top-level source directory) and their institutional affiliations.
 ** All rights reserved.  See the file COPYING in the top-level source
 ** directory for licensing information.\endverbatim
 **
 ** \brief Contains code for handling command-line options.
 **
 ** For each <module>_options.toml configuration file, mkoptions.py
 ** expands this template and generates a <module>_options.h file.
 **/

#include "cvc4_private.h"

#ifndef __CVC4__OPTIONS__PRINTER_H
#define __CVC4__OPTIONS__PRINTER_H

#include "options/options.h"

#include "options/printer_modes.h"


#define CVC4_OPTIONS__PRINTER__FOR_OPTION_HOLDER \
  instFormatMode__option_t::type instFormatMode;\
  bool instFormatMode__setByUser__; \
  modelFormatMode__option_t::type modelFormatMode;\
  bool modelFormatMode__setByUser__;


namespace CVC4 {

namespace options {

extern struct CVC4_PUBLIC instFormatMode__option_t
{
  typedef InstFormatMode type;
  type operator()() const;
  bool wasSetByUser() const;
  void set(const type& v);
} instFormatMode CVC4_PUBLIC;
extern struct CVC4_PUBLIC modelFormatMode__option_t
{
  typedef ModelFormatMode type;
  type operator()() const;
  bool wasSetByUser() const;
  void set(const type& v);
} modelFormatMode CVC4_PUBLIC;


}  // namespace options

template <> void Options::set(
    options::instFormatMode__option_t,
    const options::instFormatMode__option_t::type& x);
template <> const options::instFormatMode__option_t::type& Options::operator[](
    options::instFormatMode__option_t) const;
template <> bool Options::wasSetByUser(options::instFormatMode__option_t) const;
template <> void Options::assign(
    options::instFormatMode__option_t,
    std::string option,
    std::string value);
template <> void Options::set(
    options::modelFormatMode__option_t,
    const options::modelFormatMode__option_t::type& x);
template <> const options::modelFormatMode__option_t::type& Options::operator[](
    options::modelFormatMode__option_t) const;
template <> bool Options::wasSetByUser(options::modelFormatMode__option_t) const;
template <> void Options::assign(
    options::modelFormatMode__option_t,
    std::string option,
    std::string value);


namespace options {

inline instFormatMode__option_t::type instFormatMode__option_t::operator()() const
{
  return (*Options::current())[*this];
}
inline bool instFormatMode__option_t::wasSetByUser() const
{
  return Options::current()->wasSetByUser(*this);
}
inline void instFormatMode__option_t::set(const instFormatMode__option_t::type& v)
{
  Options::current()->set(*this, v);
}
inline modelFormatMode__option_t::type modelFormatMode__option_t::operator()() const
{
  return (*Options::current())[*this];
}
inline bool modelFormatMode__option_t::wasSetByUser() const
{
  return Options::current()->wasSetByUser(*this);
}
inline void modelFormatMode__option_t::set(const modelFormatMode__option_t::type& v)
{
  Options::current()->set(*this, v);
}


}  // namespace options
}  // namespace CVC4

#endif /* __CVC4__OPTIONS__PRINTER_H */
