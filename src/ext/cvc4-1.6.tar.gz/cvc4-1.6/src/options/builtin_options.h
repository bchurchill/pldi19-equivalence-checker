/*********************                                                        */
/*! \file module_template.h
 ** \verbatim
 ** Top contributors (to current version):
 **   Mathias Preiner
 ** This file is part of the CVC4 project.
 ** Copyright (c) 2009-2018 by the authors listed in the file AUTHORS
 ** in the top-level source directory) and their institutional affiliations.
 ** All rights reserved.  See the file COPYING in the top-level source
 ** directory for licensing information.\endverbatim
 **
 ** \brief Contains code for handling command-line options.
 **
 ** For each <module>_options.toml configuration file, mkoptions.py
 ** expands this template and generates a <module>_options.h file.
 **/

#include "cvc4_private.h"

#ifndef __CVC4__OPTIONS__BUILTIN_H
#define __CVC4__OPTIONS__BUILTIN_H

#include "options/options.h"




#define CVC4_OPTIONS__BUILTIN__FOR_OPTION_HOLDER


namespace CVC4 {

namespace options {




}  // namespace options




namespace options {




}  // namespace options
}  // namespace CVC4

#endif /* __CVC4__OPTIONS__BUILTIN_H */
